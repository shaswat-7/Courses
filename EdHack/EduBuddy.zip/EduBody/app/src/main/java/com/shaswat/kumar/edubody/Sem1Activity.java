package com.shaswat.kumar.edubody;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;

public class Sem1Activity extends AppCompatActivity {

    LinearLayout cProgramming;
    LinearLayout python;

    Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sem1);


        toolbar = findViewById(R.id.toolbar_sem1);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Semester 1");

        cProgramming = findViewById(R.id.cProgram);
        python = findViewById(R.id.python);

        ClickActivity();

    }

    public void ClickActivity(){

        cProgramming.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(getApplicationContext(), Cprogram.class);
                startActivity(intent);
            }
        });

        python.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(getApplicationContext(),python.class);
                startActivity(intent);

            }
        });
    }



}
