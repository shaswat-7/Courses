package com.shaswat.kumar.edubody;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;

import com.google.firebase.auth.FirebaseAuth;

public class show extends AppCompatActivity {

    LinearLayout sem1Button;
    LinearLayout sem2Button;
    LinearLayout sem3Button;
    LinearLayout sem4Button;
    LinearLayout sem5Button;
    LinearLayout sem6Button;

    Toolbar toolbar;
    FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show);

        sem1Button = findViewById(R.id.Sem1Layout);
        sem2Button = findViewById(R.id.Semester2Layout);
        sem3Button = findViewById(R.id.Semester3Layout);
        sem4Button = findViewById(R.id.Semester4Layout);
        sem5Button = findViewById(R.id.Semester5Layout);
        sem6Button = findViewById(R.id.Semester6Layout);

        mAuth = FirebaseAuth.getInstance();

        toolbar = findViewById(R.id.showtoolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("EduBuddy");

        ClickEvents();

    }

    public void ClickEvents(){

        sem1Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(getApplicationContext(),Sem1Activity.class);
                startActivity(intent);

            }
        });


        sem2Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(getApplicationContext(),Sem2Activity.class);
                startActivity(intent);

            }
        });


        sem3Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });



        sem4Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });


        sem5Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });

        sem6Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });





    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.logout,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.logout:
                mAuth.signOut();
                startActivity(new Intent(getApplicationContext(),MainActivity.class));
                break;
        }


        return super.onOptionsItemSelected(item);
    }



}
